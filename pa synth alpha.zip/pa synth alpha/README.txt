about the pa synth alpha commit…work in progress…

paSonifier0.1 is the closest thing to a subpath that you can drop into channelAnalysisNew.

paFlow0.1 is a master GUI that must be open after the synth is up, and preset 1 needs to be recalled to initialize synth parameters.

The Bed section works reasonably well, and the Cyc section is full of bugs and problems.

Sorry about the mess… I remember David Z opening a huge patch during a CNMAT concert once and going “oh…it’s one of *those* patches…:)

